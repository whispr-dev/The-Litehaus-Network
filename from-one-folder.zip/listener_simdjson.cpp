
#include <iostream>
#include <simdjson.h>
#include <string>
#include <thread>
#include <chrono>
#include <cstring>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

int main() {
    const int PORT = 1337;
    char buffer[2048];

    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("socket creation failed");
        return 1;
    }

    sockaddr_in addr {};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind failed");
        return 1;
    }

    std::cout << "Listening on UDP port " << PORT << "..." << std::endl;

    while (true) {
        sockaddr_in sender;
        socklen_t sender_len = sizeof(sender);
        int len = recvfrom(sock, buffer, sizeof(buffer) - 1, 0,
                           (struct sockaddr*)&sender, &sender_len);
        if (len < 0) continue;

        buffer[len] = '\0';
        std::string json_data(buffer);

        simdjson::ondemand::parser parser;
        try {
            auto doc = parser.iterate(json_data);
            std::cout << "Parsed JSON received: ";
            for (auto field : doc.get_object()) {
                std::cout << field.unescaped_key() << ": " << field.value() << ", ";
            }
            std::cout << std::endl;
        } catch (const simdjson::simdjson_error &e) {
            std::cerr << "JSON parse error: " << e.what() << std::endl;
        }
    }

    close(sock);
    return 0;
}
