
#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

int main() {
    const char* TARGET_IP = "127.0.0.1";
    const int TARGET_PORT = 1337;
    const int BEACON_INTERVAL_MS = 5000;

    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        perror("socket creation failed");
        return 1;
    }

    sockaddr_in dest {};
    dest.sin_family = AF_INET;
    dest.sin_port = htons(TARGET_PORT);
    inet_pton(AF_INET, TARGET_IP, &dest.sin_addr);

    const char* json = "{\"status\": \"alive\", \"id\": \"beacon001\"}";

    while (true) {
        sendto(sock, json, strlen(json), 0, (sockaddr*)&dest, sizeof(dest));
        std::cout << "Beacon sent to " << TARGET_IP << ":" << TARGET_PORT << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(BEACON_INTERVAL_MS));
    }

    close(sock);
    return 0;
}
