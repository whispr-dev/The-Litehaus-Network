﻿// rtc-jsonifier.cpp : Defines the entry point for the application.
//

#include "rtc-jsonifier.h"

using namespace std;

int main()
{
	cout << "Hello CMake." << endl;
	return 0;
}
