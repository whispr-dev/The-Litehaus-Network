# Security Policy

## Reporting a Vulnerability

Please use the following contact information for reporting a vulnerability:

- [Daniel Lemire](https://github.com/lemire) - daniel@lemire.me
