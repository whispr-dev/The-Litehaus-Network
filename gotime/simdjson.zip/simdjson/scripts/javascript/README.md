- npm install
- nodejs generatelargejson.js (or node generatelargejson.js)

